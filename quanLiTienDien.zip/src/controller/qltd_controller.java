package controller;

//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//
//import javax.swing.JFrame;
//import javax.swing.JOptionPane;
//import javax.swing.SwingUtilities;
//
//import view.FormMain;
//import view.dangNhapView;
//
//public class qltd_controller implements ActionListener{
// private dangNhapView dangNhapView;
//private FormMain formMain;
// 
// 
//	public qltd_controller(view.dangNhapView dangNhapView) {
//		this.dangNhapView = dangNhapView;
//}
//
//	
//
//	@Override
//    public void actionPerformed(ActionEvent e) {
//		String cm = e.getActionCommand();
//        JFrame currentFrame = (JFrame) SwingUtilities.getWindowAncestor(dangNhapView);
//        if (currentFrame != null) {
//            currentFrame.dispose();
//        }
//
//        new FormMain().setVisible(true);
//    }
//
//
//}
