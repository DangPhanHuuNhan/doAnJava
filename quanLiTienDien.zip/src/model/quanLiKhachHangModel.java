package model;

import java.util.ArrayList;

import DAO.khachHangDao;

public class quanLiKhachHangModel {
	private ArrayList<khachHang> dsKhachHang;

	
	public quanLiKhachHangModel() {
	this.dsKhachHang = new ArrayList<khachHang>();

	}


	public quanLiKhachHangModel(ArrayList<khachHang> dsKhachHang) {
		this.dsKhachHang = dsKhachHang;
	}


	public ArrayList<khachHang> getDsKhachHang() {
		return dsKhachHang;
	}


	public void setDsKhachHang(ArrayList<khachHang> dsKhachHang) {
		this.dsKhachHang = dsKhachHang;
	}
	public void them(khachHang KH) {
		this.dsKhachHang.add(KH);
	}
	
	public void xoa(khachHang KH) {
		this.dsKhachHang.remove(KH);
	}
	public void capNhat(khachHang KH) {
		this.dsKhachHang.remove(KH);
		this.dsKhachHang.add(KH);
	}
public void layDuLieuTuDatabase() {
	khachHangDao khachHangDao = new khachHangDao();
	this.dsKhachHang = khachHangDao.hienThiTatCa();
}
	
}
